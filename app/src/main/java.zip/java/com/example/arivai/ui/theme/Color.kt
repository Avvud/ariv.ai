package com.example.arivai.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette - Modern Emerald & Deep Indigo
val PrimaryLight = Color(0xFF0D9488)        // Teal Emerald
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFCCFBF1) // Soft Mint Container
val OnPrimaryContainerLight = Color(0xFF115E59)

val SecondaryLight = Color(0xFF6366F1)      // Indigo Accent
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFE0E7FF)
val OnSecondaryContainerLight = Color(0xFF3730A3)

val TertiaryLight = Color(0xFFD97706)       // Warm Amber
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFEF3C7)
val OnTertiaryContainerLight = Color(0xFF92400E)

val BackgroundLight = Color(0xFFF8FAFC)     // Soft Slate
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)

// Dark Palette - Deep Midnight Cyber Teal
val PrimaryDark = Color(0xFF2DD4BF)         // Bright Cyber Teal
val OnPrimaryDark = Color(0xFF003735)
val PrimaryContainerDark = Color(0xFF115E59)
val OnPrimaryContainerDark = Color(0xFFCCFBF1)

val SecondaryDark = Color(0xFF818CF8)       // Soft Lavender Indigo
val OnSecondaryDark = Color(0xFF1E1B4B)
val SecondaryContainerDark = Color(0xFF312E81)
val OnSecondaryContainerDark = Color(0xFFE0E7FF)

val TertiaryDark = Color(0xFFFBBF24)        // Bright Amber
val OnTertiaryDark = Color(0xFF451A03)
val TertiaryContainerDark = Color(0xFF78350F)
val OnTertiaryContainerDark = Color(0xFFFEF3C7)

val BackgroundDark = Color(0xFF0F172A)      // Midnight Navy
val OnBackgroundDark = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF334155)
val OnSurfaceVariantDark = Color(0xFFCBD5E1)
