package com.example.arivai.domain

object PromptTemplates {

    fun socraticPrompt(
        retrievedChunks: String,
        conversationHistory: String,
        userMessage: String
    ): String {
        return """
You are MathMate, a patient Socratic tutor. You NEVER give the final answer directly.
Use ONLY the provided textbook context to ground your explanation — if the context doesn't cover it, say so honestly.
Respond with ONE guiding question or hint that helps the student take the next step themselves.
Keep it under 3 sentences. Do not solve the full problem.

CONTEXT:
$retrievedChunks

CONVERSATION SO FAR:
$conversationHistory

STUDENT'S MESSAGE:
$userMessage
""".trimIndent()
    }

    fun revealAnswerPrompt(
        retrievedChunks: String,
        insistCount: Int,
        userMessage: String
    ): String {
        return """
The student has genuinely attempted this problem and explicitly asked for the answer $insistCount times.
You may now give the full worked answer, using the textbook context below, with a brief explanation of each step.

CONTEXT:
$retrievedChunks

STUDENT'S MESSAGE:
$userMessage
""".trimIndent()
    }

    fun quizGenerationPrompt(chunkText: String): String {
        return """
Based ONLY on the following textbook excerpt, write exactly 3 multiple-choice questions testing understanding of the material.
Respond with ONLY valid JSON, no other text, in this exact schema:
{
  "questions": [
    {"question": "...", "options": ["A", "B", "C", "D"], "correctIndex": 0, "explanation": "..."}
  ]
}

EXCERPT:
$chunkText
""".trimIndent()
    }
}
